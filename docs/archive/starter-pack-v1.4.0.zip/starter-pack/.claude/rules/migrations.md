---
paths:
  - "**/migrations/**"
  - "**/alembic/**"
  - "**/prisma/migrations/**"
---
# Migration rules

- Schema migrations are **append-only and NOT idempotent**: never edit or renumber a
  migration that has been applied anywhere. To change course, write a new forward migration.
- Seeds are the opposite lifecycle: **idempotent/upsert, re-runnable**, kept separate from
  schema migrations.
- Never assume a migration number is free: take the next after the last on disk; on
  collision, yield to the committed/lower owner and renumber yours higher; commit + push
  promptly to claim it.
- Migrations are applied by **`exec` inside the running backend container** (or the
  project's migrate script) — never by a host tool pointed at a DB port, and never assumed
  applied because files are mounted in `initdb.d` (that runs only on an empty volume).
- Changing an existing live structure = **expand → migrate → contract** across separate
  deploys; the destructive step is last and is the cutover.
- After adding a migration, update the cross-environment migration matrix in
  `docs/current/`.

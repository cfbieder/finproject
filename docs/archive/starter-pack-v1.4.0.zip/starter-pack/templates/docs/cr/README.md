# CR Index — <<APP>>

> **The single source of truth for what shipped when.** Other docs link here and never
> restate ship dates/versions. Shipped CRs stay in `cr/` as historical records.

| CR | Title | Status | Shipped | Version |
|---|---|---|---|---|
| [001](cr-001-architecture-foundation.md) | Architecture foundation | in progress | — | — |

**Statuses:** proposed · in progress · shipped ✓ · superseded · dropped.
Numbering: next after the last on disk; never reuse; sub-docs share the parent number
(`cr-001-phase-a-plan.md`).
